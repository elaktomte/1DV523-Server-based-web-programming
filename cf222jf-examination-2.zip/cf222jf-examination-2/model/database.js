'use strict'
const mongoose = require('mongoose')
let ObjectId = mongoose.Schema.Types.ObjectId
let snippetSchema = new mongoose.Schema({ __id: ObjectId, username: String, content: String })
let Snippet = mongoose.model('snippet', snippetSchema)
let userSchema = new mongoose.Schema({ userID: ObjectId, username: String, password: String })
let UserModel = mongoose.model('user', userSchema)

// Mongoose settings and schemas
let start = async function () {
  await mongoose.connect('mongodb://localhost:27017/test2', { useNewUrlParser: 'true' })
  var db = mongoose.connection
  await db.on('error', console.error.bind(console, 'connection error:'))
  await db.once('open', function () {
    console.log('Mongoose connected')
  })
}
module.exports = {
  start: start,
  UserModel: UserModel,
  Snippet: Snippet
}
