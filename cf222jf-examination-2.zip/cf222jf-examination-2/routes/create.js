'use strict'
const router = require('express').Router()
const Snippet = require('../model/database').Snippet

router.route('/create/')
  .get((req, res) => {
    res.render('create')
  })

  .post((req, res) => {
    if (req.session.username) {
      let name = req.session.username
      console.log(name)
      let item = new Snippet({ username: name, content: req.body.textArea })
      item.save(function (err) {
        if (err) res.status(503).send('Error when creating snippet')
      // saved!
      })
      console.log('item created!')
      res.redirect('/express-flash/create/')
    } else {
      res.status(403).send('<h1>Forbidden</h1>')
    }
  })

module.exports = router
