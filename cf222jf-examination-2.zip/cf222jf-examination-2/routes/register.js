'use strict'
const router = require('express').Router()
const UserModel = require('../model/database').UserModel
const bcrypt = require('bcrypt-nodejs')

router.route('/register/')
  .post((req, res) => {
    if (req.body.Username.length < 3 || req.body.Password.length < 8) {
      res.render('index', ({ expressFlash: 'Username has to be 3 characters long and password has to be atleast 8 characters long' }))
    } else {
      UserModel.find({ username: req.body.Username }).then(a => {
        if (a.length >= 1) { res.render('index', ({ expressFlash: 'User already exists' })) } else {
          let hash = bcrypt.hashSync(req.body.Password)

          let user = new UserModel({
            username: req.body.Username,
            password: hash
          })
          console.log('created user with Username: ' + req.body.Username + ' with the password ' + hash)
          user.save(function (err) {
            if (err) {
              res.status(503).send('Error when creating user')
            }
            res.render('index', ({ expressFlash: 'User created!' }))
          })
        }
      })
    }
  })

module.exports = router
