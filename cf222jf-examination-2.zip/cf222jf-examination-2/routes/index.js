'use strict'
let router = require('express').Router()
let UserModel = require('../model/database').UserModel
const bcrypt = require('bcrypt-nodejs')

router.route('/logout/')
  .get((req, res) => {
    req.session.username = null
    res.render('index')
  })

router.route('/')
  .get((req, res) => {
    if (req.session.username) {
      res.render('start')
    } else {
      res.render('index')
    }
  })
  .post((req, res) => {
    let userName = req.body.Username
    let passWord = req.body.Password

    UserModel.find({ username: userName }).then(e => {
      let comparison = bcrypt.compareSync(passWord, e[0].password)
      if (comparison === true) {
        req.session.username = e[0].username
        res.render('start')
      } else {
        res.render('index', ({ expressFlashLogin: 'Login failed.' }))
      }
    })
  })
module.exports = router
