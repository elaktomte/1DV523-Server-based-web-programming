'use strict'
const router = require('express').Router()
const Snippet = require('../model/database').Snippet

router.route('/read/')
  .get((req, res) => {
    Snippet.find().then(a => {
      let returnArray = []
      a.forEach(item => {
        returnArray.push({ username: item.username, snippet: item.content })
      })
      res.render('read', { snippets: returnArray })
    })
  })
module.exports = router
