'use strict'
const router = require('express').Router()
const Snippet = require('../model/database').Snippet

router.route('/delete/:snipId')
  .get((req, res) => {
    if (req.session.username) {
      let name = req.session.username
      Snippet.deleteOne({ username: name, _id: req.params.snipId }, (err, result) => {
        if (err) return res.status(503).send('Something went wrong')
        else if (result.n === 0) {
          req.session.flashMessage = 'You are not authorized to delete this post'
          res.redirect('../delete/')
        } else {
          res.redirect('../delete/')
        }
      })
    }
  })

router.route('/delete/')
  .get((req, res) => {
    if (req.session.username) {
      Snippet.find().then(a => {
        let returnArray = []
        a.forEach(item => {
          returnArray.push({ username: item.username, snippet: item.content, id: item._id })
        })
        if (req.session.flashMessage) {
          res.render('delete', { body: returnArray, expressFlash: req.session.flashMessage })
          req.session.flashMessage = null
        } else {
          res.render('delete', { body: returnArray })
        }
      })
    } else {
      res.status(403).send('<h1>Forbidden</h1>')
    }
  })
module.exports = router
