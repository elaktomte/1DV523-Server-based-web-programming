'use strict'
const router = require('express').Router()

router.route('/start/')
  .get((req, res) => {
    res.render('start')
  })

module.exports = router
