'use strict'
const router = require('express').Router()
const Snippet = require('../model/database').Snippet
router.route('/update/:snipId')
  .post((req, res) => {
    let snippet = req.body.textArea
    Snippet.findById(req.params.snipId, function (err, snip) {
      if (err) return res.status(503).send('Internal server error')
      else {
        if (snip.username === req.session.username) {
          snip.set({ content: snippet })
          snip.save(function (err) {
            if (err) return res.status(503).send('Error occured while saving an update')
            res.redirect('../update/')
          })
        } else if (snip.username !== req.session.username) {
          req.session.flashMessage = 'you are not authorized'
          res.redirect('../update/')
        }
      }
    })
  })

router.route('/update/')
  .get((req, res) => {
    if (req.session.username) {
      Snippet.find().then(a => {
        let returnArray = []
        a.forEach(item => {
          returnArray.push({ username: item.username, snippet: item.content, id: item._id })
        })
        if (req.session.flashMessage) {
          res.render('update', { body: returnArray, expressFlash: req.session.flashMessage })
          req.session.flashMessage = null
        } else {
          res.render('update', { body: returnArray })
        }
      })
    } else {
      res.status(403).send('<h1>Forbidden</h1>')
    }
  })

module.exports = router
