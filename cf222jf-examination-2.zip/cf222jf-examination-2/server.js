'use strict'
const database = require('./model/database.js')
const express = require('express')
const session = require('express-session')
const bodyParser = require('body-parser')
const handleBars = require('express-handlebars')
const path = require('path')
const flash = require('express-flash')
const cookieParser = require('cookie-parser')

// express settings
var app = express()
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.engine('handlebars', handleBars({ defaultLayout: 'main' }))
app.set('view engine', 'handlebars')
app.use(express.static(path.join(__dirname, '/public')))
process.env.PORT = process.env.PORT || 8080
app.use(cookieParser('secret'))
let sessionStore = new session.MemoryStore()
app.use(session({
  cookie: { maxAge: 6000000 },
  store: sessionStore,
  saveUninitialized: true,
  resave: 'true',
  secret: 'aposidnhgadonföouashf'
}))
app.use(flash())

app.listen(process.env.PORT, () => {
  console.log('Express listening on port %s', process.env.PORT)
})
let DBStart = async function () {
  await database.start()
  console.log('Database is connected')
}
DBStart()

// Load Routes
app.use('/', require('./routes/index.js'))
app.use('/', require('./routes/start.js'))
app.use('/', require('./routes/register.js'))
app.use('/', require('./routes/create.js'))
app.use('/', require('./routes/read.js'))
app.use('/', require('./routes/update.js'))
app.use('/', require('./routes/delete.js'))
app.use('/', require('./routes/register.js'))

// flash messages
app.all('/express-flash/create/', function (req, res) {
  req.flash('success', 'This is a flash message using the express-flash module.')
  res.render('create', ({ expressFlash: 'Item successfully created!' }))
})

// Error handling
app.use(function (request, response, next) {
  // Should have own view?
  response.status(404).send('error/404')
})

// four parameters for errors
app.use(function (err, req, res, next) {
  // log the error
  console.error(err.stack)
  res.status(500).send('Something broke!')
})
