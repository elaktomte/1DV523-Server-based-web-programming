'use strict'
const cheerio = require('cheerio')
const fetch = require('node-fetch')
/*
username: zeke
password: coys

response-header, set-cookie: qi88ZyOC0BVAZDoD6yKSpSessionId=s%3AXJ4K3Q0fTOcyPm0rF9eTtAvIQtnrSFWH.qyL1MKhWIB6g0eShAcCk5Djxz9RuzkZJqd9mLgSY
request-Header, cookie: _ga=GA1.2.1633538836.1535455223; __utmc=76804746; __utmz=76804746.1536143802.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __utma=76804746.1633538836.1535455223.1543051640.1543222835.66; __utmt=1; __utmb=76804746.1.10.1543222835; qi88ZyOC0BVAZDoD6yKSpSessionId=s%3AVmoFHaNz_YSHCJYrnaZXYAV_LSVW0Auj.r6H0w6kixn9H06tiIicnq2boRVeWo8spC%2FWhb5bKJGY
redirect address = http://vhost3.lnu.se:20080/dinner/login/booking
login adress = http://vhost3.lnu.se:20080/dinner/login
*/

const getBody = async function (link) {
  let body = await fetch(link).then(res => res.text()).then(body => cheerio.load(body))
  return body
}

let login = async function (link, initialLink) {
  let body = await getBody(link)
  let array = body('form').toArray().map(el => body(el).attr('action'))
  let url
  // checking for relative url
  if (array[0].indexOf('http://') === 0 || array[0].indexOf('https://') === 0) {
    url = link
  } else {
    url = initialLink + array[0].substring(1, array[0].length)
    // console.log(url)
  }
  /* let params = new URLSearchParams()
  params.append('username', 'zeke')
  params.append('password', 'coys')
  console.log('OwO ' + params.toString())
  */
  // console.log(params)

  let cookie
  let reservationPage = await fetch(url, { method: 'post',
    headers: {
      'Content-Type': 'application/json' // <-- Specifying the Content-Type
    },
    body: JSON.stringify({ username: 'zeke', password: 'coys' }),
    redirect: 'manual' }).then(res => {
    // console.log(res)
    cookie = res.headers.get('set-cookie')
    console.log(cookie)
    if (res.headers.get('location') !== null) { url = res.headers.get('location') }
  }).then(async e => {
    let myHeaders = ({
      'Content-Type': 'text/plain',
      'X-Custom-Header': 'ProcessThisImmediately',
      'Cookie': cookie
    })
    // console.log(url)
    let newPage = await fetch(url, { metod: 'get', headers: myHeaders })
    return newPage
  })
  reservationPage = await reservationPage.text()
  return reservationPage
}
exports.checkForAvailableTimes = async function (link, initialLink) {
  let body = await login(link, initialLink)
  // console.log(body)
  let $ = await cheerio.load(body)
  let array = $('input:radio').toArray().map(el => $(el).attr('value'))
  // console.log(array)
  return array
}
