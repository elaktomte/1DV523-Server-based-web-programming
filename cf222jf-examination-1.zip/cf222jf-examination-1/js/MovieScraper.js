'use strict'
// const cheerio = require('cheerio')
const fetch = require('node-fetch')
/* const getTheBody = async function (link, array) {
  let returnArr = await fetch(link).then(res => res.text()).then(body => cheerio.load(body)).then($ => {
    array = $('option').toArray().map(el => $(el).text().toLowerCase())
    // console.log(array)
  }).then(function () {
    return array
  })
  return returnArr
}
*/
const getMovies = async function (link, day) {
  // status 1 = available
  // http://vhost3.lnu.se:20080/cinema/check?day=05&movie=01
  // let array = []
  // array = await getTheBody(link, array)
  // console.log(array)
  let selectedDay = 0
  if (day === 'friday') { selectedDay = 5 }
  if (day === 'saturday') { selectedDay = 6 }
  if (day === 'sunday') { selectedDay = 7 }
  let movies = []
  movies.push(await fetch(link + '/check?day=0' + selectedDay + '&movie=01'))
  movies.push(await fetch(link + '/check?day=0' + selectedDay + '&movie=02'))
  movies.push(await fetch(link + '/check?day=0' + selectedDay + '&movie=03'))
  for (let i = 0; i < movies.length; i++) {
    movies[i] = await movies[i].text()
    movies[i] = await JSON.parse(movies[i])
  }
  return movies
}
exports.getAvailableMovies = async function (dates, cinemaLink) {
  let movies = []
  if (dates[0] === 3) { movies.push(await getMovies(cinemaLink, 'friday')) }
  if (dates[1] === 3) { movies.push(await getMovies(cinemaLink, 'saturday')) }
  if (dates[2] === 3) { movies.push(await getMovies(cinemaLink, 'sunday')) }
  let availableMovies = []
  for (let i = 0; i < movies.length; i++) {
    for (let j = 0; j < movies[i].length; j++) {
      for (let k = 0; k < movies[i][j].length; k++) {
        // console.log(movies[i][j])
        if (movies[i][j][k].status === 1) {
          let movieTitle = ''
          let movieDay = ''

          if (movies[i][j][k].movie === '01') { movieTitle = 'The flying deuces' }
          if (movies[i][j][k].movie === '02') { movieTitle = 'Keep your seats, please' }
          if (movies[i][j][k].movie === '03') { movieTitle = 'A day at the races' }
          if (movies[i][j][k].day === '05') { movieDay = 'friday' }
          if (movies[i][j][k].day === '06') { movieDay = 'saturday' }
          if (movies[i][j][k].day === '07') { movieDay = 'sunday' }

          availableMovies.push(Object({
            title: movieTitle,
            day: movieDay,
            timeslot: movies[i][j][k].time.substring(0, 2)
          }))
        }
      }
    }
  }
  // console.log(availableMovies)
  return availableMovies
}
