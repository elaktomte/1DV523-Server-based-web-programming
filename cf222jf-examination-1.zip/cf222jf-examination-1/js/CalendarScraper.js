'use strict'
const cheerio = require('cheerio')
const fetch = require('node-fetch')

const getBody = async function (link) {
  let body = await fetch(link).then(res => res.text()).then(body => cheerio.load(body))
  return body
}
exports.getDates = async function (link) {
  let dates = await getBody(link).then(e => {
    let array = e('td').toArray().map(el => e(el).text().toLocaleLowerCase())
    return array
  })
  return dates
}
