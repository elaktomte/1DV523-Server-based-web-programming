'use strict'
const cheerio = require('cheerio')
const fetch = require('node-fetch')
const calendarScrape = require('./js/CalendarScraper')
const movieScrape = require('./js/MovieScraper')
const restaurantScrape = require('./js/RestaurantScraper')
// let args = process.argv.slice(2)
let args = 'http://vhost3.lnu.se:20080/weekend'
// let args = 'http://cscloud304.lnu.se:8080/'
let calendarPageArr = []

if (args.length === 0) {
  console.log('ERROR: No argument(s).')
  process.exit(0)
}
// method for getting the body and getting the a tags.
const getLinks = async function (link) {
  let returnArr = await fetch(link).then(res => res.text()).then(body => cheerio.load(body)).then($ => {
    let array = $('a').toArray().map(el => $(el).attr('href'))
    // console.log(array)
    return array
  })
  return returnArr
}

try {
  getLinks(args).then(e => {
    console.log('Fetching links are done!')
    let calendarLink = e[0]
    let cinemaLink = e[1]
    let restaurantLink = e[2]
    let movies
    calendarPageArr = getLinks(e[0], calendarPageArr).then(async e => {
      for (let i = 0; i < e.length; i++) {
        // if it's not an absolute link.
        if (e[i].indexOf('http://') === 0 || e[i].indexOf('https://') === 0) {

        } else {
          e[i] = calendarLink + e[i]
        }
      }
      let days = [0, 0, 0]
      for (let i = 0; i < e.length; i++) {
        let event = await calendarScrape.getDates(e[i])
        if (event[0] === 'ok') { days[0]++ }
        if (event[1] === 'ok') { days[1]++ }
        if (event[2] === 'ok') { days[2]++ }
      }
      console.log('Fetching available dates are done')
      return days
    }).then(async e => {
      movies = await movieScrape.getAvailableMovies(e, cinemaLink)
      console.log('Fetching the available movies is done')
      return movies
    }).then(async e => {
      let availableTimes = await restaurantScrape.checkForAvailableTimes(restaurantLink, args)
      console.log('Fetching the available bookings is done')
      for (let i = 0; i < e.length; i++) {
        let time = e[i].timeslot.substring(0, 3)
        let day = e[i].day.substring(0, 3)
        for (let j = 0; j < availableTimes.length; j++) {
          if (availableTimes[j].substring(0, 5) === day + (parseInt(time) + 2)) {
            console.log('The movie ' + e[i].title + ' is available at ' + e[i].timeslot + ':00 on ' + e[i].day + ' and a table is available at ' + (parseInt(time) + 2) + ':00 at Zekes restaurant')
          }
        }
      }
    })
  })
} catch (error) {
  console.error(error)
}
